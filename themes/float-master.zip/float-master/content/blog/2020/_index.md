+++
# If set to "true", the section homepage is rendered.
# Useful when the section is used to organize pages (not used directly).
render = false

# If set to "true", the section will pass its pages on to the parent section. Defaults to `false`.
# Useful when the section shouldn't split up the parent section, like
# sections for each year under a posts section.
transparent = true
+++
