+++
title = "Blog"

# Whether to sort pages by "date", "weight", or "none". More on that below
sort_by = "date"

# How many pages to be displayed per paginated page.
# No pagination will happen if this isn't set or if the value is 0
paginate_by = 10
+++
